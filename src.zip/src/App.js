import logo from './logo.svg';
import './App.css';

import TODOApp from './TodoAppComponents/TodoApp';

function App() {
  return (
    <div className="App">
      <TODOApp />
    </div>
  );
}

export default App;
