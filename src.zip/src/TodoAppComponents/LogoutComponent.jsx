
export function LogoutComponent(){
    return(
        <div>
            <h1>Logged Out successfully!!</h1>
        </div>
    )
}