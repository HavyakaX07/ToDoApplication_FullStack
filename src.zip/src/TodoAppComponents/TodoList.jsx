import { useState, useEffect } from "react";
import { retriewTodosForUser, deleteTodoAPI } from "./Common/ToDoAPIService";
import {useNavigate}  from 'react-router-dom';

export function TodoComponent() {
    const today = new Date();
    const targetDate = new Date(today.getFullYear() + 12, today.getMonth(), today.getDate());
    const nav = useNavigate();

    const [todos, setTodos] = useState([]);
    const [todoId, setTodoId] = useState(-1);
    const [selectedTodo, setSelectedTodo] = useState(null);

    useEffect(() => {
        getTodos(1);
    }, []);

    function getTodos(userId) {
        retriewTodosForUser(userId)
            .then(response => setTodos(response.data))
            .catch(error => console.log(error));
    }

    function deleteTodo(id) {
        deleteTodoAPI(id)
            .then(response => {
                setTodoId(id);
                getTodos(1);
            })
            .catch(error => console.log(error));
    }

    function updateTodoDetails(todoId) {
        nav(`/update-todo/${todoId}`);
    }


    return (
        <div className="container">
            {todoId !== -1 && <div className="alert alert-warning"> LAST DELETED TODO ID : {todoId} </div>}
            <table className="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NAME</th>
                        <th>DESCRIPTION</th>
                        <th>IS DONE?</th>
                        <th>TARGET DATE</th>
                        <th>DELETE</th>
                        <th>UPDATE</th>
                    </tr>
                </thead>
                <tbody>
                    {todos.map(todo => (
                        <tr key={todo.todoId}>
                            <td>{todo.todoId}</td>
                            <td>{todo.todoName}</td>
                            <td>{todo.todoDescription}</td>
                            <td>{todo.done.toString()}</td>
                            <td>{todo.targetDate}</td>
                            <td><button className="btn btn-warning" onClick={() => deleteTodo(todo.todoId)}>DELETE</button></td>
                            <td><button className="btn btn-success" onClick={()=> updateTodoDetails(todo.todoId)}>UPDATE</button></td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <button className="btn btn-success m5" onClick={()=> updateTodoDetails(-1)}>ADD TODO</button>
        </div>
        
    );
}
