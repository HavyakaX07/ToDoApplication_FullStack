import { useState } from "react";
import {BrowserRouter,Routes,Route,useNavigate,useParams, Link} from 'react-router-dom';
import { useAuth } from "./Common/Security";
import {doBasicAuthenticationAPI} from "./Common/ToDoAPIService"

import "./LoginComponent.css"

export function LoginComponent(){
    const ctxt = useAuth()
    const setVal = ctxt.setAuth 

    const [userName,setUserName] = useState('root');
    const [password,setPassword] = useState('');

    const nav = useNavigate();

    const[isSuccess,setSuccess] = useState(false);
    const[isFail,setFail] = useState(false);

    function handleUserNameChange(event){
        setUserName(event.target.value);
    }

    function handlePasswordChange(event){
        setPassword(event.target.value);
    }

    async function validatePassword(){
        if(await ctxt.login(userName,password)){
            console.log("Validation success")
            setFail(false);
            nav(`/welcome/${userName}`);
        }
        else{
            setFail(true);
        }
    }

    return(
        <div className="LoginComponent">
            {isFail && <div> Login Failed</div>}
            <div class="container">
        <div class="login-form" action="#">
            <h2>Login</h2>
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required onChange={handleUserNameChange}/>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required onChange={handlePasswordChange} />
            </div>
            <button type="submit" onClick={validatePassword}>Login</button>
            <div class="register-link">
                <span>Don't have an account? </span>
                <a href="register">Register</a>
            </div>
        </div>
    </div>
        </div>
    )
}