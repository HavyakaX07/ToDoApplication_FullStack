import { useState } from "react";
import {BrowserRouter,Routes,Route,useNavigate,useParams, Link, Navigate} from 'react-router-dom';
import {HearderComponent} from './Common/Header'
import {FooterComponent} from './Common/Footer'
import {LoginComponent} from './LoginComponent'
import {TodoComponent} from './TodoList'
import {ErrorComponent} from './Common/ErrorComponent'
import { LogoutComponent } from "./LogoutComponent";
import AuthProvider, { useAuth } from "./Common/Security";
import {TodoModal} from "./Common/ToDoModel"
import {RegistrationComponent} from "./RegistrationComponent" 

function AuthenticatedRoute({children}){
    const ctxt = useAuth()
    if(ctxt.isAuthenticated){
        return children
    }
    return <Navigate to="/" />
}
export default function TODOApp(){
    return(
        <div className="TODOApp">
            <AuthProvider>
            <BrowserRouter>
            <HearderComponent/>
                <Routes>
                    <Route path='/' element={<LoginComponent />} />
                    <Route path='/login' element={<LoginComponent />} />
                    <Route path="/register" element={<RegistrationComponent />} />
                    <Route path='/welcome/:userName' element={
                    <AuthenticatedRoute>
                        <WelcomeComponent />
                    </AuthenticatedRoute>
                    } />
                    <Route path='/update-todo/:todoId' element={
                    <AuthenticatedRoute>
                        <TodoModal />
                    </AuthenticatedRoute>
                    } />
                    <Route path='/todos' element={
                    <AuthenticatedRoute>
                        <TodoComponent />
                    </AuthenticatedRoute>
                    } />
                    <Route path='/logout' element={
                    <AuthenticatedRoute>
                        <LogoutComponent />
                    </AuthenticatedRoute>
                    } />
                    <Route path='*' element={<ErrorComponent />} />
                </Routes>
               <FooterComponent/>
            </BrowserRouter>
            </AuthProvider>
        </div>
    );
}



function WelcomeComponent(){
    const {userName} =useParams();
    return(
        <>
        <div>Welcome {userName}
        </div>
        <div>Mange todos <Link to="/todos">Here</Link></div>
        </>
    )
}






