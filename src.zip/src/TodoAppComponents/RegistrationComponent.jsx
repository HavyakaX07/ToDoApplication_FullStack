import { registerUser } from "./Common/ToDoAPIService";
 export function RegistrationComponent(){
    
    function handleRegistration(){
        registerUser().then(response => console.log(response)).catch(error=> console.log(error))
    }
    
    return (

        <div class="container">
        <div class="registration-form" action="#">
            <h2>Register</h2>
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required />
            </div>
            <div class="input-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required/>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required/>
            </div>
            <button type="submit" onClick={handleRegistration}>Register</button>
            <div class="login-link">
                <span>Already have an account? </span>
                <a href="/login">Login</a>
            </div>
        </div>
    </div>
    )
}