
import './FooterComponent.css'
export function FooterComponent() {
    return (
    <footer className="footer">
        <div className="container">
            To-do-app
        </div>
    </footer>
    )
}