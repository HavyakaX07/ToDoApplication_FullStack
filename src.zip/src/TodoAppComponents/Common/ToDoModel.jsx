import {useNavigate, useParams} from 'react-router-dom'
import { useState, useEffect } from "react";
import {retriewTodoAPI,updateTodoAPI,createTodoAPI} from "./ToDoAPIService"

export function TodoModal() {
    
    const {todoId} = useParams();

    const [todo, setTodo] = useState({
        todoName: "",
        todoDescription: "",
        targetDate: "",
        done: false,
        todoId:todoId
    });

    function getTodoDetails(){
        retriewTodoAPI(todoId,1).then(response => {
            setTodo({
                todoName: response.data.todoName,
                todoDescription: response.data.todoDescription,
                targetDate: response.data.targetDate,
                done: response.data.isDone,
                todoId:todoId
            })
        }).
        catch(error => console.log(error))
    }

    const nav = useNavigate()
    useEffect(() => {
        console.log(todoId)
        getTodoDetails();
    }, [todoId]);

    const handleUpdate = () => {
        if(todoId!=-1){
        updateTodoAPI(todo)
            .then(response => {
                nav("/todos")
            })
            .catch(error => console.log(error));
        }
        else{
            createTodoAPI(todo)
            .then(response => {
                nav("/todos")
            })
            .catch(error => console.log(error));
        }
    };

    const handleChange = (e) => {
        console.log(e)
        const { name, value, type, checked } = e.target;
        const val = type === "checkbox" ? checked : value;
        setTodo(prevTodo => ({
            ...prevTodo,
            [name]: val
        }));
    };

    return (
        <div className="container mt-5 d-flex justify-content-center">
            <div className="col-md-6">
                <div className="card">
                    <h5 className="card-header text-center">Update Todo Details</h5>
                    <div className="card-body">
                        <form>
                            <div className="form-group">
                                <label htmlFor="todoName" style={{color: 'blue'}}>Name</label>
                                <input type="text" className="form-control" id="todoName" name="todoName" value={todo.todoName} onChange={handleChange} />
                            </div>
                            <div className="form-group">
                                <label htmlFor="todoDescription" style={{color: 'red'}}>Description</label>
                                <textarea className="form-control" id="todoDescription" name="todoDescription" value={todo.todoDescription} onChange={handleChange}></textarea>
                            </div>
                            <div className="form-group">
                                <label htmlFor="targetDate">Target Date</label>
                                <input type="date" className="form-control" id="targetDate" name="targetDate" value={todo.targetDate} onChange={handleChange} />
                            </div>
                            <div className="form-group">
                                <div className="form-check">
                                    <input type="checkbox" className="form-check-input" id="isDone" name="done" checked={todo.done} onChange={handleChange} />
                                    <label className="form-check-label" htmlFor="isDone">Is Done</label>
                                </div>
                            </div>
                            <button type="button" className="btn btn-primary mr-2" onClick={handleUpdate}>SAVE TODO
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
