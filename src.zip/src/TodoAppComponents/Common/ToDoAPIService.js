
import axios from 'axios'

export const axiosClient = axios.create({
    baseURL : 'http://localhost:8080'
});

export const retriewTodosForUser = (userId)=> axiosClient.get(`users/${userId}/todos`)
export const deleteTodoAPI = (todoId)=> axiosClient.delete(`deleteTodos/${todoId}`)
export const retriewTodoAPI = (todoId,userId)=> axiosClient.get(`users/${userId}/todos/${todoId}`)
export const updateTodoAPI = (todo) => axiosClient.post('updateTodos',todo)
export const createTodoAPI = (todo) => axiosClient.post('addTodos',todo)

export const doBasicAuthenticationAPI = (token) => axiosClient.get('/login',{
    headers:{
        Authorization : token
    }
})

export const registerUser = ()=> axiosClient.post('/register')