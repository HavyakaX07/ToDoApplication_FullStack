import { createContext, useContext, useState } from "react";

import {doBasicAuthenticationAPI} from "./ToDoAPIService"

import { axiosClient } from "./ToDoAPIService"

//Create context
const AuthContext = createContext()


//Create hook to make use it other components
export const useAuth = () => useContext(AuthContext)




//create function to make available context in all component
export default function AuthProvider({children}){
    const [isAuthenticated,setAuth] = useState(false)
    const [token,setToken] = useState(null)

     async function login(username, password) {

        const baToken = 'Basic ' + window.btoa( username + ":" + password )

        try {

            const response = await doBasicAuthenticationAPI(baToken)

            if(response.status==200){
                setAuth(true)
                setToken(baToken)

                axiosClient.interceptors.request.use(
                    (config) => {
                        console.log('intercepting and adding a token')
                        config.headers.Authorization = baToken
                        return config
                    }
                )

                return true            
            } else {
                logout()
                return false
            }    
        } catch(error) {
            logout()
            return false
        }
    }

    function logout(userName,password){
            setAuth(false)
    }

    return(
        <AuthContext.Provider value={{isAuthenticated,login,logout}}>
            {children}
        </AuthContext.Provider>
    )
}